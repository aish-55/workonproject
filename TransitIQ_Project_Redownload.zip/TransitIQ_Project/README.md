# TransitIQ — Public Transportation Data Analytics
## A YARN Approach to Pattern Discovery

### Run the project
1. Extract `TransitIQ_Project.zip`.
2. Open `index.html` in a modern browser (Chrome, Edge or Firefox).
3. Internet access is required to load Chart.js and Google Fonts from their CDNs.
4. Navigate using the left sidebar. Use Data Studio to upload `sample_transport_data.csv` or your own CSV.

### Features
- Overview dashboard with passenger, duration, revenue and on-time KPIs.
- Interactive ridership trend, transport-mode share, hourly demand and route charts.
- Pattern Explorer: weekday demand, journey-duration distribution, demand windows and automatically generated insights.
- Route Insights: route passenger comparison, average delays and a performance table.
- Data Studio: CSV upload, validation, sample CSV download and demo-data restore.
- YARN-inspired processing pipeline demonstration with ingestion, resource scheduling, mapper and reducer stages.

### CSV format
Required columns: `date`, `route`, `mode`, `passengers`.
Optional columns: `trip_id`, `hour`, `duration_min`, `delay_min`, `fare`.
The parser accepts common aliases such as `passenger_count`, `transport_mode`, `travel_date`, `duration`, and `delay`.
Use dates in `YYYY-MM-DD` format and hour values from 0 to 23.

### Important academic note
This is a front-end academic prototype. The YARN page demonstrates the conceptual Hadoop YARN + MapReduce workflow. Data aggregation and chart generation run in the browser; no Hadoop cluster, ResourceManager, NodeManager or distributed containers are actually connected. For a full distributed implementation, connect a backend using Hadoop YARN, HDFS and a MapReduce/Spark job, then expose the processed results through an API.

### Suggested viva explanation
"TransitIQ analyzes public transport trip records to discover temporal and route-level demand patterns. The workflow is inspired by Hadoop YARN: data is ingested, compute resources are conceptually scheduled, mapper-style grouping creates key-value aggregates, and reducer-style aggregation produces metrics used by the dashboard. These patterns can support decisions such as adjusting peak-hour frequency, identifying delayed routes and planning capacity."
