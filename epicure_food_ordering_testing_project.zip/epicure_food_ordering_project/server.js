const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data", "orders.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const menu = [
  ["Truffle Parmesan Fries","Crispy golden fries, parmesan snow and truffle aioli.","Small plates",349,"https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=900"],
  ["Burrata & Heirloom Tomato","Creamy burrata, ripe tomatoes, basil oil and aged balsamic.","Small plates",649,"https://images.unsplash.com/photo-1608039829572-78524f79c4c7?w=900"],
  ["Crispy Lotus Stem","Honey chilli glaze, toasted sesame and spring onion.","Small plates",429,"https://images.unsplash.com/photo-1547592180-85f173990554?w=900"],
  ["Dynamite Prawns","Crispy prawns tossed in a creamy, gently spiced sauce.","Small plates",699,"https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?w=900"],
  ["Wild Mushroom Toast","Sourdough, sautéed mushrooms, herbs and whipped ricotta.","Small plates",499,"https://images.unsplash.com/photo-1525351484163-7529414344d8?w=900"],
  ["Charred Corn Ribs","Smoky corn, lime, chilli butter and coriander.","Small plates",379,"https://images.unsplash.com/photo-1551759005-9c5a9cb0b7d5?w=900"],
  ["Classic Caesar Salad","Romaine hearts, parmesan, sourdough croutons and dressing.","Salads",449,"https://images.unsplash.com/photo-1546793665-c74683f339c1?w=900"],
  ["Watermelon Feta Salad","Chilled watermelon, feta, mint and citrus dressing.","Salads",429,"https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=900"],
  ["Avocado Garden Bowl","Avocado, greens, quinoa, cucumber and lemon tahini.","Salads",549,"https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=900"],
  ["Butter Chicken","Tandoor chicken simmered in a silky tomato makhani gravy.","Indian",649,"https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=900"],
  ["Paneer Lababdar","Soft paneer in a rich tomato-cashew gravy.","Indian",529,"https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=900"],
  ["Dal Makhani","Slow-cooked black lentils finished with butter and cream.","Indian",449,"https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=900"],
  ["Chicken Dum Biryani","Aromatic basmati, tender chicken and fragrant whole spices.","Indian",599,"https://images.unsplash.com/photo-1563379091339-03246963d96c?w=900"],
  ["Hyderabadi Veg Biryani","Layered basmati rice, vegetables, saffron and mint.","Indian",499,"https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=900"],
  ["Garlic Naan Basket","Soft tandoor naan brushed with garlic butter.","Indian",199,"https://images.unsplash.com/photo-1601050690597-df0568f70950?w=900"],
  ["Miso Glazed Salmon","Pan-seared salmon, sweet miso glaze and sesame greens.","Asian",999,"https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=900"],
  ["Thai Green Curry","Fragrant coconut curry, seasonal vegetables and jasmine rice.","Asian",599,"https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=900"],
  ["Pad Thai Noodles","Wok-tossed rice noodles, tamarind, peanuts and lime.","Asian",549,"https://images.unsplash.com/photo-1559314809-0d155014e29e?w=900"],
  ["Sushi Platter","Chef's selection of fresh vegetarian sushi rolls.","Asian",799,"https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=900"],
  ["Crispy Chilli Tofu","Golden tofu, chilli-garlic sauce and scallions.","Asian",499,"https://images.unsplash.com/photo-1547592180-85f173990554?w=900"],
  ["Wild Mushroom Risotto","Creamy arborio rice, wild mushrooms and parmesan.","Mains",749,"https://images.unsplash.com/photo-1476124369491-e7addf5db371?w=900"],
  ["Grilled Chicken Steak","Herb-marinated chicken, seasonal vegetables and jus.","Mains",799,"https://images.unsplash.com/photo-1544025162-d76694265947?w=900"],
  ["Four Cheese Pizza","Mozzarella, parmesan, gorgonzola and basil.","Mains",699,"https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=900"],
  ["Classic Margherita","San Marzano tomato, fior di latte and fresh basil.","Mains",599,"https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=900"],
  ["Chocolate Fondant","Warm chocolate cake with a molten centre and vanilla ice cream.","Desserts",399,"https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=900"],
  ["Biscoff Cheesecake","Creamy baked cheesecake with a caramelised biscuit base.","Desserts",429,"https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=900"],
  ["Tiramisu","Espresso-soaked sponge, mascarpone and cocoa.","Desserts",399,"https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=900"],
  ["Mango Panna Cotta","Silky vanilla panna cotta with seasonal mango.","Desserts",379,"https://images.unsplash.com/photo-1488477181946-6428a0291777?w=900"],
  ["Berry Sparkler","Mixed berries, lime and sparkling soda.","Drinks",249,"https://images.unsplash.com/photo-1513558161293-cison?w=900"],
  ["Cold Coffee","Slow-brew coffee, chilled milk and a hint of vanilla.","Drinks",279,"https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=900"]
].map((x, i) => ({ id: i + 1, name: x[0], description: x[1], category: x[2], price: x[3], image: x[4] }));

const readOrders = () => {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
};
const writeOrders = (orders) => {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(orders, null, 2));
};

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "Epicure API" }));
app.get("/api/menu", (_req, res) => res.json(menu));
app.post("/api/orders", (req, res) => {
  const { customer, items } = req.body || {};
  if (!customer || !customer.name || !customer.phone || !customer.address || !customer.email) {
    return res.status(400).json({ error: "Please provide all customer details." });
  }
  if (!/^[6-9]\d{9}$/.test(String(customer.phone))) {
    return res.status(400).json({ error: "Enter a valid 10-digit Indian mobile number." });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email)) {
    return res.status(400).json({ error: "Enter a valid email address." });
  }
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "Your cart is empty." });
  }
  const normalized = [];
  for (const item of items) {
    const dish = menu.find(m => m.id === Number(item.id));
    const qty = Number(item.quantity);
    if (!dish || !Number.isInteger(qty) || qty < 1 || qty > 20) {
      return res.status(400).json({ error: "One or more cart items are invalid." });
    }
    normalized.push({ id: dish.id, name: dish.name, price: dish.price, quantity: qty, lineTotal: dish.price * qty });
  }
  const subtotal = normalized.reduce((sum, item) => sum + item.lineTotal, 0);
  const delivery = subtotal >= 999 ? 0 : 49;
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + delivery + tax;
  const order = {
    orderId: "EP" + Date.now().toString().slice(-8),
    createdAt: new Date().toISOString(),
    customer: { name: customer.name.trim(), phone: String(customer.phone), email: customer.email.trim(), address: customer.address.trim() },
    items: normalized, subtotal, delivery, tax, total, status: "Confirmed"
  };
  const orders = readOrders();
  orders.push(order);
  writeOrders(orders);
  res.status(201).json(order);
});
app.get("/api/orders/:id", (req, res) => {
  const order = readOrders().find(o => o.orderId === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  res.json(order);
});
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Epicure is running at http://localhost:${PORT}`));
