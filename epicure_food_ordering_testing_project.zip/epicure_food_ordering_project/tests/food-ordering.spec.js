const { test, expect } = require("@playwright/test");

test.describe("Epicure food ordering application", () => {
  test("homepage loads and displays at least 25 menu items", async ({ page }) => {
    await page.goto("/");
    await expect(page.locator("h1")).toContainText("Good food");
    await expect(page.locator('[data-testid="dish-card"]')).toHaveCount(30);
  });

  test("menu category filter displays matching dishes", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "Desserts", exact: true }).click();
    await expect(page.locator('[data-testid="dish-card"]')).toHaveCount(4);
    await expect(page.getByText("Biscoff Cheesecake")).toBeVisible();
  });

  test("search finds a dish by name", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("searchbox", { name: "Search dishes" }).fill("Butter Chicken");
    await expect(page.locator('[data-testid="dish-card"]')).toHaveCount(1);
    await expect(page.getByText("Butter Chicken")).toBeVisible();
  });

  test("dish details open and add item to bag", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "DETAILS" }).first().click();
    await expect(page.locator("#dishModal")).toBeVisible();
    await page.getByRole("button", { name: "ADD TO BAG +" }).click();
    await expect(page.locator("#cartCount")).toHaveText("1");
  });

  test("cart quantity and subtotal update correctly", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "Add Truffle Parmesan Fries to bag" }).click();
    await page.getByRole("button", { name: "Open cart" }).click();
    await expect(page.locator("#cartDrawer")).toHaveClass(/open/);
    await page.getByRole("button", { name: "Increase Truffle Parmesan Fries" }).click();
    await expect(page.locator("#cartCount")).toHaveText("2");
    await expect(page.locator("#cartSubtotal")).toHaveText("₹698");
  });

  test("checkout rejects invalid phone number", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "Add Truffle Parmesan Fries to bag" }).click();
    await page.getByRole("button", { name: "Open cart" }).click();
    await page.getByRole("button", { name: /PROCEED TO CHECKOUT/ }).click();
    await page.locator('input[name="name"]').fill("Test User");
    await page.locator('input[name="phone"]').fill("12345");
    await page.locator('input[name="email"]').fill("test@example.com");
    await page.locator('textarea[name="address"]').fill("12 Test Street, Bengaluru");
    await page.getByRole("button", { name: /PLACE MY ORDER/ }).click();
    await expect(page.locator("#checkoutModal")).toBeVisible();
  });

  test("successful checkout creates order and shows bill", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: "Add Truffle Parmesan Fries to bag" }).click();
    await page.getByRole("button", { name: "Open cart" }).click();
    await page.getByRole("button", { name: /PROCEED TO CHECKOUT/ }).click();
    await page.locator('input[name="name"]').fill("Aarav Test");
    await page.locator('input[name="phone"]').fill("9876543210");
    await page.locator('input[name="email"]').fill("aarav@example.com");
    await page.locator('textarea[name="address"]').fill("12 Test Street, Bengaluru, Karnataka");
    await page.getByRole("button", { name: /PLACE MY ORDER/ }).click();
    await expect(page.locator("#successModal")).toBeVisible();
    await expect(page.locator("#successOrderId")).toContainText("EP");
    await expect(page.locator("#successTotal")).toHaveText("₹415");
    await expect(page.locator("#cartCount")).toHaveText("0");
  });

  test("backend health endpoint responds successfully", async ({ request }) => {
    const response = await request.get("/api/health");
    expect(response.ok()).toBeTruthy();
    expect(await response.json()).toMatchObject({ status: "ok" });
  });

  test("backend prevents an empty cart order", async ({ request }) => {
    const response = await request.post("/api/orders", {
      data: {
        customer: { name: "Test User", phone: "9876543210", email: "test@example.com", address: "12 Test Street, Bengaluru" },
        items: []
      }
    });
    expect(response.status()).toBe(400);
    expect(await response.json()).toHaveProperty("error", "Your cart is empty.");
  });

  test("backend rejects invalid mobile number", async ({ request }) => {
    const response = await request.post("/api/orders", {
      data: {
        customer: { name: "Test User", phone: "123", email: "test@example.com", address: "12 Test Street, Bengaluru" },
        items: [{ id: 1, quantity: 1 }]
      }
    });
    expect(response.status()).toBe(400);
    expect(await response.json()).toHaveProperty("error");
  });
});