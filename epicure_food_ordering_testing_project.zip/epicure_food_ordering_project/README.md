# EPICURE — Online Food Ordering & Delivery System
**Software Testing Mini Project | Playwright + JavaScript + Express**

A luxury-inspired restaurant ordering demo with 30 dishes, working search and category filters, dish descriptions, cart, quantity controls, checkout, server-side validation, automatic bill calculation and order confirmation.

> This is a student demo application. It does not collect payment or connect to a real restaurant/delivery service. The visual direction is inspired by premium restaurant websites; branding, copy and implementation are original.

## Requirements
- Node.js 18 or newer
- npm
- Playwright-supported browser binaries

## Run the website
```bash
npm install
npm start
```
Open **http://localhost:3000**.

## Run automated tests
In a second terminal:
```bash
npx playwright install
npm test
```
The configured test projects run on Chromium and Firefox. Open the report:
```bash
npm run test:report
```

## Main features
- 30 menu items across 7 categories
- Search by dish name or description
- Dish detail modal with image, category, description and price
- Cart drawer with add, remove and quantity update
- Automatic subtotal, 5% demo tax and delivery charge (₹49 below ₹999; free above)
- Checkout form with client and server validation
- Server-calculated bill (client cannot choose the final price)
- Order ID and itemized receipt after successful order
- Orders saved to `data/orders.json`
- API endpoints: `GET /api/health`, `GET /api/menu`, `POST /api/orders`, `GET /api/orders/:id`

## Project structure
```text
epicure_food_ordering_project/
├── data/
│   └── orders.json
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── tests/
│   └── food-ordering.spec.js
├── package.json
├── playwright.config.js
├── server.js
├── TEST-PLAN.md
└── README.md
```

## Billing rules
- Subtotal = sum of dish price × quantity
- Delivery = ₹49 when subtotal is below ₹999; otherwise ₹0
- Tax = rounded 5% of subtotal
- Total = subtotal + delivery + tax

## Suggested four-week team plan (5 members)
1. Week 1 — Requirements, UI design, menu and API setup.
2. Week 2 — Cart, checkout, server validation and bill generation.
3. Week 3 — Playwright test design, implementation and cross-browser runs.
4. Week 4 — Defect analysis, report screenshots, final report and presentation.

## Notes for submission
- Replace team member names, roll numbers, guide, department and college details in your final report/presentation.
- Run the tests on your own machine and use the actual generated pass/fail counts and execution time. Do not report sample or assumed results as real execution results.
- Add screenshots from your running website and Playwright HTML report to the college's 30–50 page report and 16-slide presentation.
- Remote food photography and Google Fonts require internet access. The app and ordering API work locally; if a remote image fails, the UI uses a fallback image.
