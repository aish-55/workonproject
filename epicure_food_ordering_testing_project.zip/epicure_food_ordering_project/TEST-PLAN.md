# Test Plan — Epicure Online Food Ordering System

## 1. Purpose
Validate the main customer journey: browse menu, search/filter dishes, inspect details, manage cart, calculate bill, submit checkout details and receive an order confirmation.

## 2. Scope
**In scope:** home page, menu API, 30-item menu, category filters, search, dish details, cart operations, quantity validation, checkout form validation, server-side order validation, bill calculation, order persistence and confirmation interface.

**Out of scope:** real payment gateway, live delivery partner integration, customer authentication, production-grade database, restaurant admin portal and real-time tracking.

## 3. Test types
- Functional testing
- UI and navigation testing
- Positive and negative testing
- API testing
- Integration / end-to-end testing
- Cross-browser testing (Chromium and Firefox)
- Basic responsive layout checks (extend with mobile project if required)

## 4. Entry criteria
- Node.js and npm installed
- Dependencies installed
- Application starts at `http://localhost:3000`
- Menu API returns HTTP 200

## 5. Exit criteria
- All critical checkout and billing tests pass
- No open critical/high severity defects
- HTML report generated
- Failed tests investigated and documented

## 6. Sample test cases

| ID | Scenario | Test data / steps | Expected result |
|---|---|---|---|
| TC01 | Open homepage | Navigate to `/` | Home page loads |
| TC02 | Menu count | Load menu | 30 dishes are displayed |
| TC03 | Category filter | Select Desserts | Only dessert dishes appear |
| TC04 | Search dish | Search Butter Chicken | Matching dish appears |
| TC05 | Open details | Select Details on a dish | Description and price appear |
| TC06 | Add to cart | Add one dish | Cart count becomes 1 |
| TC07 | Increase quantity | Increase cart quantity | Quantity and subtotal update |
| TC08 | Remove item | Remove a cart item | Item disappears |
| TC09 | Empty cart checkout | Attempt checkout with no items | Checkout remains unavailable |
| TC10 | Invalid phone | Enter 12345 | Order is not submitted |
| TC11 | Invalid email | Enter malformed email | Browser/server rejects input |
| TC12 | Valid order | Submit valid customer and cart data | HTTP 201 and confirmation |
| TC13 | Bill calculation | Place order for ₹349 item | Subtotal ₹349, delivery ₹49, tax ₹17, total ₹415 |
| TC14 | Empty order API | POST empty items array | HTTP 400 with validation message |
| TC15 | Invalid item API | POST unknown dish ID | HTTP 400 |
| TC16 | Invalid quantity API | POST quantity 0 or 21 | HTTP 400 |
| TC17 | Health API | GET `/api/health` | HTTP 200 and status ok |
| TC18 | Retrieve order | GET existing order ID | Stored order is returned |
| TC19 | Unknown order | GET unknown order ID | HTTP 404 |
| TC20 | Cross-browser run | Run suite in Chromium and Firefox | Tests execute in both browsers |

## 7. Defect report template

| Bug ID | Description | Severity | Priority | Status |
|---|---|---|---|---|
| BUG-01 | Fill after test execution | Based on impact | Based on urgency | Open / Fixed |

Do not claim defects were found unless they are reproduced. Record actual defects discovered during execution.

## 8. Execution
```bash
npm install
npx playwright install
npm test
npm run test:report
```
The HTML report is generated in `playwright-report/`. Screenshots, videos and traces are retained for failed/retried tests as configured.
