const state = { menu: [], cart: {}, activeCategory: "All", lastOrder: null };
const $ = (id) => document.getElementById(id);
const money = (n) => "₹" + Number(n).toLocaleString("en-IN");
const categories = ["All","Small plates","Salads","Indian","Asian","Mains","Desserts","Drinks"];
const safeImage = (img) => img || "https://images.unsplash.com/photo-1547592180-85f173990554?w=900";

async function loadMenu() {
  try {
    const response = await fetch("/api/menu");
    if (!response.ok) throw new Error("Menu unavailable");
    state.menu = await response.json();
    renderFilters(); renderMenu();
  } catch (error) {
    $("menuGrid").innerHTML = '<div class="loading">We could not load the menu. Please refresh the page.</div>';
  }
}
function renderFilters() {
  $("filters").innerHTML = categories.map(c => `<button class="filter-btn ${state.activeCategory===c?"active":""}" data-category="${c}">${c}</button>`).join("");
  $("filters").querySelectorAll("button").forEach(btn => btn.addEventListener("click", () => {
    state.activeCategory = btn.dataset.category; renderFilters(); renderMenu();
  }));
}
function renderMenu() {
  const query = $("searchInput").value.trim().toLowerCase();
  const dishes = state.menu.filter(d => (state.activeCategory==="All" || d.category===state.activeCategory) && (d.name.toLowerCase().includes(query) || d.description.toLowerCase().includes(query)));
  if (!dishes.length) { $("menuGrid").innerHTML = '<div class="loading">No dishes found. Try another search.</div>'; return; }
  $("menuGrid").innerHTML = dishes.map(d => `<article class="dish-card" data-testid="dish-card">
    <div class="dish-photo"><img loading="lazy" src="${safeImage(d.image)}" alt="${d.name}" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1547592180-85f173990554?w=900'"><span class="dish-tag">${d.category}</span></div>
    <div class="dish-body"><h3>${d.name}</h3><p>${d.description}</p><div class="dish-foot"><span class="price">${money(d.price)}</span><div class="dish-buttons"><button class="small-btn view-btn" data-id="${d.id}">DETAILS</button><button class="small-btn add-btn" data-id="${d.id}" aria-label="Add ${d.name} to bag">+ ADD</button></div></div></div>
  </article>`).join("");
  $("menuGrid").querySelectorAll(".add-btn").forEach(b => b.addEventListener("click", () => addToCart(Number(b.dataset.id))));
  $("menuGrid").querySelectorAll(".view-btn").forEach(b => b.addEventListener("click", () => openDish(Number(b.dataset.id))));
}
function addToCart(id) {
  state.cart[id] = (state.cart[id] || 0) + 1;
  renderCart(); toast("Added to your bag");
}
function changeQty(id, delta) {
  state.cart[id] = (state.cart[id] || 0) + delta;
  if (state.cart[id] <= 0) delete state.cart[id];
  renderCart();
}
function cartItems() { return Object.entries(state.cart).map(([id, quantity]) => ({ dish: state.menu.find(d => d.id===Number(id)), quantity })).filter(x => x.dish); }
function totals() {
  const subtotal = cartItems().reduce((s,x) => s + x.dish.price*x.quantity, 0);
  return { subtotal, delivery: subtotal===0 || subtotal>=999 ? 0 : 49, tax: Math.round(subtotal*.05), total: subtotal + (subtotal===0 || subtotal>=999 ? 0 : 49) + Math.round(subtotal*.05) };
}
function renderCart() {
  const items = cartItems(), count = items.reduce((s,x)=>s+x.quantity,0), t=totals();
  $("cartCount").textContent=count; $("drawerCount").textContent=`(${count})`; $("cartSubtotal").textContent=money(t.subtotal);
  $("checkoutButton").disabled=count===0;
  $("cartItems").innerHTML = items.length ? items.map(({dish,quantity}) => `<div class="cart-line"><div><h4>${dish.name}</h4><small>${money(dish.price)} each</small><div class="qty-control"><button data-action="minus" data-id="${dish.id}" aria-label="Decrease ${dish.name}">−</button><span>${quantity}</span><button data-action="plus" data-id="${dish.id}" aria-label="Increase ${dish.name}">+</button></div></div><div><strong>${money(dish.price*quantity)}</strong><br><button class="remove" data-action="remove" data-id="${dish.id}">Remove</button></div></div>`).join("") : '<div class="empty-cart">Your bag is waiting for something delicious.</div>';
  $("cartItems").querySelectorAll("[data-action]").forEach(b => b.addEventListener("click", () => {
    const id=Number(b.dataset.id), action=b.dataset.action;
    if(action==="plus") changeQty(id,1); else if(action==="minus") changeQty(id,-1); else { delete state.cart[id]; renderCart(); }
  }));
}
function openDish(id) {
  const d=state.menu.find(x=>x.id===id); if(!d)return;
  $("dishImage").src=safeImage(d.image); $("dishImage").alt=d.name; $("dishCategory").textContent=d.category;
  $("dishName").textContent=d.name; $("dishDescription").textContent=d.description; $("dishPrice").textContent=money(d.price);
  $("dishAdd").onclick=()=>{addToCart(id);closeModal("dishModal");};
  openModal("dishModal");
}
function openModal(id){$(id).classList.add("show");document.body.style.overflow="hidden";}
function closeModal(id){$(id).classList.remove("show");document.body.style.overflow="";}
function openCart(){ $("cartDrawer").classList.add("open"); $("cartOverlay").classList.add("show"); }
function closeCart(){ $("cartDrawer").classList.remove("open"); $("cartOverlay").classList.remove("show"); }
function toast(message){$("toast").textContent=message;$("toast").classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>$("toast").classList.remove("show"),1800);}
$("searchInput").addEventListener("input",renderMenu);
$("cartButton").addEventListener("click",openCart); $("closeCart").addEventListener("click",closeCart); $("cartOverlay").addEventListener("click",closeCart);
$("checkoutButton").addEventListener("click",()=>{closeCart();const t=totals();$("checkoutTotal").textContent=money(t.total);$("formError").textContent="";openModal("checkoutModal");});
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>closeModal(b.dataset.close)));
document.querySelectorAll(".modal-backdrop").forEach(back=>back.addEventListener("click",e=>{if(e.target===back)closeModal(back.id);}));
$("checkoutForm").addEventListener("submit",async e=>{
  e.preventDefault(); const button=$("placeOrderButton"); button.disabled=true;button.textContent="PLACING ORDER...";
  $("formError").textContent="";
  const form=new FormData(e.currentTarget);
  const customer={name:form.get("name"),phone:form.get("phone"),email:form.get("email"),address:form.get("address")};
  const items=cartItems().map(x=>({id:x.dish.id,quantity:x.quantity}));
  try{
    const response=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({customer,items})});
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||"Unable to place order.");
    state.lastOrder=data;state.cart={};renderCart();closeModal("checkoutModal");showReceipt(data);e.currentTarget.reset();
  }catch(err){$("formError").textContent=err.message;}
  finally{button.disabled=false;button.innerHTML='PLACE MY ORDER <span>→</span>';}
});
function showReceipt(order){
  $("successOrderId").textContent=order.orderId;
  $("receiptLines").innerHTML=order.items.map(i=>`<div class="receipt-line"><span>${i.name} × ${i.quantity}</span><strong>${money(i.lineTotal)}</strong></div>`).join("")+
  `<div class="receipt-line"><span>Subtotal</span><span>${money(order.subtotal)}</span></div><div class="receipt-line"><span>Delivery</span><span>${money(order.delivery)}</span></div><div class="receipt-line"><span>Tax (5%)</span><span>${money(order.tax)}</span></div>`;
  $("successTotal").textContent=money(order.total);openModal("successModal");
}
$("doneButton").addEventListener("click",()=>closeModal("successModal"));
loadMenu(); renderCart();
